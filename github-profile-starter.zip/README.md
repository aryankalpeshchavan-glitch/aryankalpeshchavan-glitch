# Aryan Chavan

## developer.yml

```yaml
developer:
  name: Aryan Chavan
  role: Aspiring DevOps Engineer
  focus:
    - Linux
    - Docker
    - Cloud Computing
    - Automation
  languages:
    - Python
    - C
    - Java
    - SQL
    - JavaScript
  technologies:
    - Git
    - GitHub
    - React
    - OpenCV
  currently_building:
    - SignSpeak
  learning:
    - AWS
    - Kubernetes
    - Terraform
    - CI/CD
```

---

### GitHub Stats
Replace `YOUR_USERNAME` with `aryankalpeshchavan-glitch`.

![Stats](https://github-readme-stats.vercel.app/api?username=YOUR_USERNAME&show_icons=true&theme=github_dark)

![Top Langs](https://github-readme-stats.vercel.app/api/top-langs/?username=YOUR_USERNAME&layout=compact&theme=github_dark)

![Streak](https://streak-stats.demolab.com?user=YOUR_USERNAME&theme=github-dark)

## Tech Stack
`Python` `C` `Java` `SQL` `React` `Git` `Linux` `Docker`

## Projects
- SignSpeak
- Portfolio
- Python Practice
- DSA

## Roadmap
- [x] Git
- [x] GitHub
- [ ] Linux
- [ ] Docker
- [ ] AWS
- [ ] Kubernetes
- [ ] Terraform

---
> Build • Automate • Deploy • Improve
